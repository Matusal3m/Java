def retornaSoma(n1, n2):
    return n1 + n2

n1 = int(input('Insira um valor\n'))
n2 = int(input('Insira outro valor\n'))

print(retornaSoma(n1, n2))